import numpy as np
from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation
from keras.layers import Conv1D, GlobalMaxPooling1D
import glob
import os
from random import shuffle

#preprocessor to load your documents
#pass the train and the test set to the below funciton to create dataset of postive and negative data

def pre_process_data(file_path):
    positive_path = os.path.join(file_path, 'pos')
    negative_path = os.path.join(file_path, 'neg')
    pos_label = 1
    neg_label = 0
    dataset = []

    for filename in glob.glob(os.path.join(positive_path, '*.txt')):
        with open(filename, 'r') as f:
            dataset.append((pos_label, f.read()))
    for filename in glob.glob(os.path.join(negative_path,"*.txt")):
        with open(filename) as f:
            dataset.append((neg_label, f.read()))
    shuffle(dataset)

    return dataset
train_dataset = pre_process_data('/home/muhammed/Documents/nlpia_codes/ch7/aclImdb/train')
test_dataset = pre_process_data('/home/muhammed/Documents/nlpia_codes/ch7/aclImdb/test')
dataset = train_dataset + test_dataset
print(dataset[0])
#vectorizer and tokenizer
#tokenizer is to tokenize the document, into sentences and the sentences into words (tokens)
#vectorizer is to find the word2vce representation of each token from the tokenization phase
#note here we used GoogleNews word2vec

from nltk.tokenize import TreebankWordTokenizer
from gensim.models.keyedvectors import KeyedVectors
from nlpia.loaders import get_data

EMBEDDING_FILE = '/home/muhammed/Documents/nlpia_codes/GoogleNews-vectors-negative300.bin' # from above
word_vectors = KeyedVectors.load_word2vec_format(EMBEDDING_FILE, limit = 200000,binary=True)

def tokenize_and_vectorize(dataset):
    tokenizer = TreebankWordTokenizer()
    vectorized_data = []
   
    for sample in dataset:
        tokens = tokenizer.tokenize(sample[1])
        #the document is tokenized into sentences and sentences into tokens
        sample_vecs = []
        for token in tokens:
            try:
                sample_vecs.append(word_vectors[token])
            except:
                pass #No matching token in the Google w2v
        vectorized_data.append(sample_vecs)
    return vectorized_data

#collect the targe

def collect_expected(dataset):
    expected = []
    for sample in dataset:
        expected.append(sample[0])
    return expected

expected = collect_expected(dataset)

split_point = int(len(vecotized_data)*.8)